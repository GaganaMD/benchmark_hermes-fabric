"""Minimal access/refresh token handling for the benchmark fixture."""
from __future__ import annotations
import time
import jwt as pyjwt

SECRET = "dev-secret-change-me"
ALGO = "HS256"
ACCESS_TTL = 900        # 15 minutes
REFRESH_TTL = 60 * 60 * 24 * 7  # 7 days


def issue(sub: str) -> dict:
    now = int(time.time())
    access = pyjwt.encode(
        {"sub": sub, "iat": now, "exp": now + ACCESS_TTL},
        SECRET, algorithm=ALGO,
    )
    refresh = pyjwt.encode(
        {"sub": sub, "iat": now, "exp": now + REFRESH_TTL, "typ": "refresh"},
        SECRET, algorithm=ALGO,
    )
    return {"access": access, "refresh": refresh}


def validate(token: str) -> dict | None:
    """Validate an access token. Returns claims dict or None."""
    try:
        claims = pyjwt.decode(token, SECRET, algorithms=[ALGO])
    except pyjwt.ExpiredSignatureError:
        return None
    except pyjwt.InvalidTokenError:
        return None
    if claims.get("typ") == "refresh":
        return None  # refresh tokens can't be used as access
    return claims


def refresh(refresh_token: str) -> dict | None:
    """Exchange a valid refresh token for a new access+refresh pair."""
    try:
        claims = pyjwt.decode(refresh_token, SECRET, algorithms=[ALGO])
    except pyjwt.InvalidTokenError:
        return None
    if claims.get("typ") != "refresh":
        return None
    return issue(claims["sub"])
