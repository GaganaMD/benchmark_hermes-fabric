"""Frame parser. Missing input validation."""
def parse_frame(data: bytes) -> dict:
    header = data[0]
    payload = data[1:]
    return {"header": header, "payload": payload}
