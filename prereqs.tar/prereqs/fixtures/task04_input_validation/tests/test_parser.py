from src.parser import parse_frame

def test_handles_basic():
    result = parse_frame(b"\x01hello")
    assert result["header"] == 0x01
    assert result["payload"] == b"hello"

def test_handles_multi_byte_payload():
    result = parse_frame(b"\xff\x00\x01\x02")
    assert result["header"] == 0xff
    assert result["payload"] == b"\x00\x01\x02"
