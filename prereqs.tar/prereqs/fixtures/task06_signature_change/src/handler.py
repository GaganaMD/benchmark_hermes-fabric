from src.proto import decode_packet

def handle(raw: bytes) -> str:
    pkt = decode_packet(raw)
    if not pkt["ok"]:
        return "drop"
    return f"type={pkt['type']}"
