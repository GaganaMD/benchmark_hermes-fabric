"""Packet decoder."""
def decode_packet(buf: bytes) -> dict:
    if len(buf) < 2:
        return {"ok": False, "reason": "short"}
    return {"ok": True, "type": buf[0], "len": buf[1], "body": buf[2:]}
