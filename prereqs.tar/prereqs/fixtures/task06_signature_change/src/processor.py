from src.proto import decode_packet

def process_batch(raws):
    out = []
    for r in raws:
        pkt = decode_packet(r)
        if pkt["ok"]:
            out.append(pkt)
    return out
