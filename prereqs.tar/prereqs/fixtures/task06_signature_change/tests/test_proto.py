from src.proto import decode_packet

def test_short():
    assert decode_packet(b"\x01")["ok"] is False

def test_basic():
    p = decode_packet(b"\x02\x03abc")
    assert p["ok"] is True
    assert p["type"] == 0x02
    assert p["len"] == 0x03
    assert p["body"] == b"abc"
