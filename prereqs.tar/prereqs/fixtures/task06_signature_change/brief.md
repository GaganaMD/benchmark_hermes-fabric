# TASK
Change `decode_packet(buf)` to `decode_packet(buf, *, strict=False)` in `src/proto.py`. Update all callers within `src/`. Tests in `tests/test_proto.py` must still pass without modification.

# FILES IN SCOPE
- `src/proto.py`
- `src/handler.py`
- `src/processor.py`

# FORBIDDEN PATHS
- `tests/` — no changes allowed

# DONE WHEN
- `decode_packet` in `src/proto.py` has signature `decode_packet(buf, *, strict=False)`
- All call sites inside `src/` work under the new signature (default `strict=False` is acceptable)
- When `strict=True`, malformed packets raise `ValueError` instead of returning `{"ok": False}`
- `git diff -- tests/` is empty
- `pytest -x` exits 0
- `rg "decode_packet\(" src/` shows >= 3 hits (def + handler + processor)

# VERIFICATION COMMANDS
```bash
pytest -x
git diff --quiet tests/
rg -q "def decode_packet\(buf, \*, strict=False\)" src/proto.py
```

# CONSTRAINTS
- Keep the dict return shape for the non-strict path.
- No new dependencies.
