from pathlib import Path
from src.config import load_config

def test_loads_ini(tmp_path, monkeypatch):
    ini = tmp_path / "config.ini"
    ini.write_text("[server]\nhost = 1.2.3.4\nport = 9000\n")
    monkeypatch.chdir(tmp_path)
    cfg = load_config()
    assert cfg["server"]["host"] == "1.2.3.4"
    assert cfg["server"]["port"] == "9000"
