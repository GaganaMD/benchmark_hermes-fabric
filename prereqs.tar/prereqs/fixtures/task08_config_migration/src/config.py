"""Flat INI config loader."""
import configparser
from pathlib import Path

def load_config(path: str = "config.ini") -> dict:
    parser = configparser.ConfigParser()
    if not Path(path).exists():
        raise FileNotFoundError(path)
    parser.read(path)
    return {section: dict(parser[section]) for section in parser.sections()}
