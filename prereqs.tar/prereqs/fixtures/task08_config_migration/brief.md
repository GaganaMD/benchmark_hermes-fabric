# TASK
Migrate config loading from flat `config.ini` to nested `config.toml`. Keep `config.ini` loading as a deprecated fallback for one release. Existing tests must pass unmodified; add new tests for the TOML path.

# FILES IN SCOPE
- `src/config.py`
- `tests/test_config.py` (additions only — do not delete or modify existing tests)
- new file (optional): `tests/test_config_toml.py`
- new file (optional): example `config.toml` if useful for fixtures

# FORBIDDEN PATHS
- None, but stay surgical

# DONE WHEN
- `load_config` prefers `config.toml` when present, falls back to `config.ini`
- Loading from `config.ini` emits a `DeprecationWarning` mentioning the toml migration
- Existing `test_loads_ini` still passes unmodified (verify with `git diff`)
- At least 3 new test cases cover: toml-only, ini-only-emits-warning, both-present-prefers-toml
- `pytest -x` exits 0

# VERIFICATION COMMANDS
```bash
pytest -x
# existing test should be byte-identical
git show baseline:tests/test_config.py > /tmp/orig_test_config.py
diff /tmp/orig_test_config.py <(grep -A 100 "def test_loads_ini" tests/test_config.py | head -10)
```

# CONSTRAINTS
- Use stdlib `tomllib` (Python 3.11+). No external TOML library.
- Schema for `config.toml`:
  ```toml
  [server]
  host = "0.0.0.0"
  port = 8080
  [db]
  url = "sqlite:///app.db"
  pool_size = 5
  ```
