from src.workers import dispatch

def test_run_task_happy_path(monkeypatch):
    monkeypatch.setattr(dispatch, "fetch_from_broker", lambda tid: {"n": 21})
    result = dispatch.run_task(lambda p: p["n"] * 2, "t1")
    assert result == 42
