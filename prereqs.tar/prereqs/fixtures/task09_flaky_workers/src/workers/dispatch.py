"""Background task dispatcher. No retry, no idempotency. Often loses work."""
from typing import Callable, Any

_results: dict[str, Any] = {}

class BrokerError(Exception):
    pass

def fetch_from_broker(task_id: str) -> dict:
    """Pretend to fetch a task from a broker. Raises BrokerError sometimes."""
    # In real life: pubsub/redis/sqs. Here: a stub that the test will patch.
    raise NotImplementedError("inject me in tests")

def run_task(handler: Callable[[dict], Any], task_id: str) -> Any:
    """Fetch and run one task. No retry. No idempotency."""
    payload = fetch_from_broker(task_id)
    result = handler(payload)
    _results[task_id] = result
    return result
