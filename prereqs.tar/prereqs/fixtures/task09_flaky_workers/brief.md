# TASK
Improve reliability of the background worker in `src/workers/dispatch.py`. Add retry-with-backoff on `BrokerError` and idempotency on `task_id`. Add tests proving both.

# FILES IN SCOPE
- `src/workers/dispatch.py`
- `tests/test_workers.py` (additions to existing file)

# FORBIDDEN PATHS
- None, but stay within scope

# DONE WHEN
- `run_task` retries on `BrokerError` with exponential backoff (max_retries configurable, default 3)
- `run_task` is idempotent: if `task_id` is already in `_results`, return the cached result without re-invoking the handler
- Backoff delays are mockable for fast tests (e.g. accept a `sleep` callable parameter, default `time.sleep`)
- Existing `test_run_task_happy_path` still passes unmodified
- New test `test_retries_on_broker_error` proves retry happens N times and eventually succeeds
- New test `test_gives_up_after_max_retries` proves a final `BrokerError` is raised after exhaustion
- New test `test_idempotent` proves the handler is invoked exactly once for the same `task_id`
- `pytest -x` exits 0

# VERIFICATION COMMANDS
```bash
pytest -x
pytest tests/test_workers.py::test_idempotent -v
pytest tests/test_workers.py::test_retries_on_broker_error -v
```

# CONSTRAINTS
- Stdlib only. No tenacity, no backoff library.
- Keep `BrokerError` as the retryable exception class.
- Backoff: 0.1s, 0.2s, 0.4s by default (tests should override with a no-op sleep).
