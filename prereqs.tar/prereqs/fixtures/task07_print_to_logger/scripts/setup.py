# This file is in scripts/ and must NOT be modified.
print("setup: bootstrapping dev environment")
print("setup: ok")
