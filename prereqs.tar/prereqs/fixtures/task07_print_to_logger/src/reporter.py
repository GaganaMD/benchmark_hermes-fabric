def report(rows):
    print(f"reporter: summarizing {len(rows)} rows")
    summary = {"n": len(rows)}
    print("reporter: done")
    return summary
