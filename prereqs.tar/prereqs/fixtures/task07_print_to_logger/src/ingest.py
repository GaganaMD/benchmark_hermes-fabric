def ingest(path):
    print(f"ingest: opening {path}")
    with open(path) as f:
        rows = f.readlines()
    print(f"ingest: read {len(rows)} rows")
    return rows
