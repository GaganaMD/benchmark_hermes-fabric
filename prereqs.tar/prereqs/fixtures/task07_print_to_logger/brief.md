# TASK
Replace every `print(...)` call in `src/` with `logger.info(...)`. Add `import logging` and `logger = logging.getLogger(__name__)` to each file that has prints but lacks a logger. Do not touch `scripts/`.

# FILES IN SCOPE
- All files under `src/`

# FORBIDDEN PATHS
- `scripts/` — any change here is a failure
- `__init__.py` files (no need to touch them)

# DONE WHEN
- `rg "print\(" src/` returns no hits
- `rg "print\(" scripts/` shows the original prints (untouched)
- Every modified file imports `logging` and defines a module-level `logger`
- `python -c "import src.ingest, src.reporter"` succeeds (modules still load)
- `git diff --quiet scripts/`

# VERIFICATION COMMANDS
```bash
! rg -q "print\(" src/
git diff --quiet scripts/
python -c "import src.ingest, src.reporter"
```

# CONSTRAINTS
- Preserve the f-string formatting; just swap the call.
- Do not change function signatures or return values.
