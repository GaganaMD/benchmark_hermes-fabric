"""Simple file-touching CLI. Click-based."""
import click
from pathlib import Path

@click.group()
def cli():
    pass

@cli.command()
@click.argument("name")
@click.option("--content", default="hello\n")
def write(name, content):
    """Write CONTENT to a file named NAME."""
    Path(name).write_text(content)
    click.echo(f"wrote {name}")

@cli.command()
@click.argument("name")
@click.option("--suffix", default=".bak")
def rename(name, suffix):
    """Rename NAME to NAME+SUFFIX."""
    src = Path(name)
    dst = src.with_suffix(src.suffix + suffix)
    src.rename(dst)
    click.echo(f"renamed {name} -> {dst}")

if __name__ == "__main__":
    cli()
