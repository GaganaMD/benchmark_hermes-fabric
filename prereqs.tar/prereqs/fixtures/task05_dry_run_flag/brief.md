# TASK
Add a `--dry-run` flag to the CLI in `src/cli.py` that prevents any file writes. Add a test in `tests/test_cli.py` proving no writes occur in dry-run.

# FILES IN SCOPE
- `src/cli.py`
- `tests/test_cli.py`

# FORBIDDEN PATHS
- Anything else

# DONE WHEN
- `--dry-run` is accepted at the group level OR on each subcommand (document which in a docstring)
- `write` and `rename` subcommands respect the flag and skip mutating filesystem actions
- In dry-run mode the CLI prints what it would do (e.g. `would write out.txt`) and exits 0
- A new test invokes `--dry-run write out.txt --content x`, asserts `out.txt` was NOT created, and the command exits 0
- All existing tests still pass
- `pytest -x` exits 0

# VERIFICATION COMMANDS
```bash
pytest -x
```

# CONSTRAINTS
- click only; do not add new dependencies.
