from click.testing import CliRunner
from src.cli import cli

def test_write_creates_file(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(cli, ["write", "out.txt", "--content", "hi"])
    assert result.exit_code == 0
    assert (tmp_path / "out.txt").read_text() == "hi"
