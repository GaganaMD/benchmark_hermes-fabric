# TASK
Make `tests/test_parser.py::test_handles_empty` pass. The test expects `parse_frame(b"")` to return `None`.

# FILES IN SCOPE
- `src/parser.py`

# FORBIDDEN PATHS
- `tests/` — any change here is a failure
- Anything outside `src/parser.py`

# DONE WHEN
- `pytest tests/test_parser.py::test_handles_empty` exits 0
- `pytest` (full suite) exits 0
- `git diff -- tests/` is empty

# VERIFICATION COMMANDS
```bash
pytest -x
git diff --quiet tests/
```

# CONSTRAINTS
- Preserve existing behavior on non-empty input.
- No new dependencies.
