"""Frame parser. Currently crashes on empty input."""
from typing import Optional

def parse_frame(data: bytes) -> Optional[dict]:
    # BUG: indexing into empty bytes raises IndexError.
    # Spec (per tests): empty input must return None.
    header = data[0]
    payload = data[1:]
    return {"header": header, "payload": payload}
