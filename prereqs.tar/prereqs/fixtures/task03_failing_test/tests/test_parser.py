from src.parser import parse_frame

def test_handles_basic():
    result = parse_frame(b"\x01hello")
    assert result["header"] == 0x01
    assert result["payload"] == b"hello"

def test_handles_empty():
    # empty input must return None, not crash
    assert parse_frame(b"") is None
