# Task 10: fm CLI

Target dir: `tools/fm/`

The agent should generate the whole project from scratch here.
