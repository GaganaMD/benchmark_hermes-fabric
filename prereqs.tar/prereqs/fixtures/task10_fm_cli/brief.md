# TASK
Build a small file-management CLI in `tools/fm/`. Commands: `list`, `move`, `tag`, `search-by-tag`. Built with click. Tested with pytest. Tags stored in a sqlite db colocated with the managed root.

# FILES IN SCOPE
- All files under `tools/fm/` (this directory is yours to build out)

# FORBIDDEN PATHS
- Anything outside `tools/fm/`

# FILE LAYOUT (suggested)
```
tools/fm/
├── __init__.py
├── cli.py            # click entry point, `python -m tools.fm.cli`
├── db.py             # sqlite schema and queries
├── ops.py            # list, move, tag, search-by-tag implementations
└── tests/
    ├── __init__.py
    └── test_fm.py
```

# COMMANDS

## `fm list <root>`
Print every file under `<root>` (recursive), one per line, path relative to `<root>`. Exit 0 even if empty.

## `fm move <src> <dst>`
Move the file. Update any tag records pointing at the old path (preserve all tags).

## `fm tag <path> <tag>`
Add a tag to a file. Tags are arbitrary non-empty strings. A file may have many tags. A tag may be on many files. Adding the same (path, tag) twice is a no-op.

## `fm search-by-tag <root> <tag>`
Print every file under `<root>` that has `<tag>`, path relative to `<root>`, one per line.

# DB SCHEMA
SQLite file at `<root>/.fm.db`. Created lazily on first write.

```sql
CREATE TABLE files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT UNIQUE NOT NULL
);
CREATE TABLE tags (
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    PRIMARY KEY (file_id, tag)
);
```

# DONE WHEN
- `python -m tools.fm.cli list .` works in an empty dir (prints nothing, exit 0)
- `tag README.md draft && search-by-tag . draft` prints `README.md`
- `move README.md NOTES.md && search-by-tag . draft` prints `NOTES.md`
- `pytest tools/fm/tests/` exits 0 with at least 4 tests covering list, move, tag, search-by-tag
- `python -m tools.fm.cli --help` shows all four subcommands

# VERIFICATION COMMANDS
```bash
pytest tools/fm/tests/
python -m tools.fm.cli --help
```

# CONSTRAINTS
- click only, no other CLI lib.
- stdlib `sqlite3`.
- Paths stored in DB as relative-to-root; the CLI converts as needed.
- `move` is atomic from the user's POV: file moved AND tags updated, or neither.
