"""Business logic for user lifecycle."""
import hashlib
import secrets
from db.repo import insert_user, get_user_by_email

class UserExists(Exception):
    pass

def _hash_password(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000).hex()

def signup_user(email: str, password: str) -> int:
    if get_user_by_email(email):
        raise UserExists(email)
    salt = secrets.token_bytes(16)
    pw_hash = _hash_password(password, salt)
    return insert_user(email=email, password_hash=pw_hash, salt=salt.hex())
