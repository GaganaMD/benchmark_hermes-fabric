"""SQLite-backed user repository."""
import sqlite3
from typing import Optional

_DB = "users.db"
_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
)
"""

def _conn() -> sqlite3.Connection:
    c = sqlite3.connect(_DB)
    c.execute(_SCHEMA)
    return c

def get_user_by_email(email: str) -> Optional[dict]:
    with _conn() as c:
        row = c.execute("SELECT id, email FROM users WHERE email = ?", (email,)).fetchone()
        return {"id": row[0], "email": row[1]} if row else None

def insert_user(*, email: str, password_hash: str, salt: str) -> int:
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO users (email, password_hash, salt) VALUES (?, ?, ?)",
            (email, password_hash, salt),
        )
        return cur.lastrowid
