"""HTTP-layer handlers. No framework; pretend this is wired to FastAPI/Flask."""
from services.user import signup_user, UserExists

def post_signup(request: dict) -> dict:
    email = (request.get("email") or "").strip().lower()
    password = request.get("password") or ""
    if not email or not password:
        return {"status": 400, "error": "missing fields"}
    if len(password) < 8:
        return {"status": 400, "error": "password too short"}
    try:
        user_id = signup_user(email, password)
    except UserExists:
        return {"status": 409, "error": "email already registered"}
    return {"status": 201, "user_id": user_id}
